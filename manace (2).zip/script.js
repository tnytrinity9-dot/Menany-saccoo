const routes=[
["Nairobi","Nanyuki","500"],["Nairobi","Nyeri","600"],["Nairobi","Karatina","700"],["Nairobi","Meru","1000"],["Nairobi","Nkubu","900"],["Nairobi","Maua","1000"],["Nairobi","Nyahururu","700"],["Nairobi","Nakuru","800"],["Nairobi","Eldoret","1400"],
["Nanyuki","Meru","600 / 300"],["Nanyuki","Nkubu","600"],["Nanyuki","Maua","700"],["Nanyuki","Nyahururu","400"],["Nanyuki","Nakuru","500"],["Nanyuki","Eldoret","1200"],
["Meru","Nkubu","300"],["Meru","Maua","400"],["Meru","Nyeri","900"],["Meru","Nakuru","1000"],["Meru","Eldoret","1600"],
["Nyeri","Nakuru","500"],["Nyeri","Eldoret","1300"],["Nkubu","Maua","200"]
];
const list=document.querySelector("#routesList"), search=document.querySelector("#search"), filter=document.querySelector("#filter");
function draw(){let q=search.value.toLowerCase(), f=filter.value.toLowerCase();let data=routes.filter(r=>{let text=(r[0]+" "+r[1]).toLowerCase();return (!q||text.includes(q))&&(f==="all"||r[0].toLowerCase()===f)});list.innerHTML=data.map((r,i)=>`<article class="route"><span class="fare">KSh ${r[2]}</span><small>${r[0]} route</small><h3>${r[0]} → ${r[1]}</h3><button onclick="chooseRoute('${r[0]}','${r[1]}')">Book this route</button></article>`).join("");document.querySelector("#empty").hidden=!!data.length}
search.addEventListener("input",draw);filter.addEventListener("change",draw);draw();
const from=document.querySelector("#from"),to=document.querySelector("#to");const places=[...new Set(routes.flatMap(r=>[r[0],r[1]]))].sort();[from,to].forEach(s=>s.innerHTML='<option value="">Select</option>'+places.map(p=>`<option>${p}</option>`).join(""));
function chooseRoute(a,b){from.value=a;to.value=b;document.querySelector("#booking").scrollIntoView({behavior:"smooth"});}
document.querySelector("#form").addEventListener("submit",e=>{e.preventDefault();const n=document.querySelector("#name").value,d=document.querySelector("#date").value,p=document.querySelector("#people").value,m=document.querySelector("#msg").value;const text=`Hello Menany Sacco, I would like to book a trip.%0A%0AName: ${encodeURIComponent(n)}%0AFrom: ${encodeURIComponent(from.value)}%0ATo: ${encodeURIComponent(to.value)}%0ADate: ${encodeURIComponent(d)}%0APassengers: ${encodeURIComponent(p)}%0AMessage: ${encodeURIComponent(m)}`;window.open(`https://wa.me/254755176122?text=${text}`,"_blank")});
document.querySelector("#year").textContent=new Date().getFullYear();
document.querySelector("#menu").onclick=()=>{document.querySelector("#nav").style.display=document.querySelector("#nav").style.display==="flex"?"none":"flex"};
const lightbox = document.querySelector("#lightbox");
const lightimg = document.querySelector("#lightimg");
const closeLightbox = document.querySelector("#close");

document.querySelectorAll(".gallery button").forEach(button => {
  button.addEventListener("click", () => {
    lightimg.src = button.dataset.img;
    lightbox.classList.add("show");
  });
});

closeLightbox.addEventListener("click", () => {
  lightbox.classList.remove("show");
  lightimg.src = "";
});

lightbox.addEventListener("click", (e) => {
  if (e.target === lightbox) {
    lightbox.classList.remove("show");
    lightimg.src = "";
  }
});};
const obs=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add("reveal");obs.unobserve(e.target)}}),{threshold:.12});
document.querySelectorAll(".section,.quickgrid a,.servicegrid article,.gallery button,.booking form,.contactin").forEach(x=>obs.observe(x));
document.querySelectorAll(".counter").forEach(el=>{let done=false;new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting&&!done){done=true;let target=+el.dataset.n,n=0;let t=setInterval(()=>{n++;el.textContent=n;if(n>=target)clearInterval(t)},45)}})).observe(el)});
